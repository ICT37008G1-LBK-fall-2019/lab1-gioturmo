var name = 'daviti';
var admin = name;
alert (admin);